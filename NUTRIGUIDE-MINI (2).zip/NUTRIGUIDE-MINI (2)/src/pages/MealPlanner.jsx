import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PreferencesForm from '@/components/mealPlanner/PreferencesForm';
import MealPlanDisplay from '@/components/mealPlanner/MealPlanDisplay';
import NutritionChart from '@/components/mealPlanner/NutritionChart';
import PersonalizedHealthInsights from '@/components/mealPlanner/FoodsToAvoid';
import { generateMealPlan } from '@/lib/mealGenerator';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, UtensilsCrossed } from 'lucide-react';

const MealPlanner = () => {
  const [preferences, setPreferences] = useState(() => {
    const savedPrefs = localStorage.getItem('mealPlannerPreferences');
    return savedPrefs ? JSON.parse(savedPrefs) : {
      healthConditions: [],
      cuisines: [], 
      dietaryPreferences: [], 
      allergies: [],
    };
  });
  const [mealPlan, setMealPlan] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showNutritionChart, setShowNutritionChart] = useState(true); // Control chart visibility

  const mealPlanRef = useRef(null);
  
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem('mealPlannerPreferences', JSON.stringify(preferences));
  }, [preferences]);

  const handlePreferencesSubmit = (newPreferences) => {
    setIsLoading(true);
    setPreferences(newPreferences);
    setMealPlan(null); 
    //setShowNutritionChart(true); // Reset chart visibility on new plan

    setTimeout(() => {
      try {
        const plan = generateMealPlan(newPreferences);
        setMealPlan(plan);
        
        toast({
          title: 'Meal Plan Generated! 🍽️',
          description: 'Your personalized weekly meal plan is ready.',
          variant: 'default',
          duration: 3000,
        });
      } catch (error) {
        setShowNutritionChart(false); // Hide chart if generation fails or data is problematic
        toast({
          title: 'Uh oh! Something went wrong. 😟',
          description: error.message || 'Could not generate meal plan. Please try again.',
          variant: 'destructive',
        });
        console.error("Error generating meal plan:", error);
      } finally {
        setIsLoading(false);
      }
    }, 1500);
  };

  const nutritionData = {
    protein: 35, 
    fats: 25,
    carbs: 30, 
    fiber: 10,
    // vitamins: 5 // Example if you want to add more
  };


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-10 pb-10"
    >
      <PreferencesForm onSubmit={handlePreferencesSubmit} initialPreferences={preferences} isLoading={isLoading} />

      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-col justify-center items-center py-16 space-y-5"
          >
            <UtensilsCrossed className="animate-spin h-20 w-20 text-primary" />
            <p className="text-2xl font-semibold text-primary-text">Crafting your delicious week...</p>
            <p className="text-secondary-text text-center max-w-sm">This might take a moment, good things come to those who wait! We're picking the best options for you.</p>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div ref={mealPlanRef}>
        <AnimatePresence>
          {mealPlan && !isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              transition={{ duration: 0.6, delay: 0.1, ease: "circOut" }}
              className="space-y-10"
            >
              <MealPlanDisplay mealPlan={mealPlan} preferences={preferences} />
              {showNutritionChart && <NutritionChart data={nutritionData} />}
              <PersonalizedHealthInsights healthConditions={preferences.healthConditions} allergies={preferences.allergies} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {!mealPlan && !isLoading && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="mt-10 bg-gradient-to-br from-primary/5 via-card to-accent/5 border-border shadow-lg rounded-lg">
            <CardHeader className="items-center text-center p-8">
              <Lightbulb className="h-16 w-16 text-primary mb-4" />
              <CardTitle className="text-3xl text-primary-text font-bold">
                Ready to Plan Your Perfect Week?
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center pb-8 px-6">
              <p className="text-secondary-text max-w-md mx-auto text-base">
                Fill out your preferences above, and NutriGuide will generate a personalized, healthy, and delicious meal plan just for you. 
                Let's get started on your wellness journey!
              </p>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </motion.div>
  );
};

export default MealPlanner;