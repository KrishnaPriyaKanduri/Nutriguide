import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { mealTypes, daysOfWeek, foodItems, cuisinesList, dietaryPreferencesList } from '@/data/mealData';
import { CalendarDays, Printer, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MealPlanDisplay = ({ mealPlan, preferences }) => {
  if (!mealPlan) return null;

  const getIllustrativeNutrition = (mealName) => {
    const foodItem = foodItems.find(item => item.name === mealName);
    if (foodItem && foodItem.illustrativeNutrition) {
      return foodItem.illustrativeNutrition.replace("Approx. ", "");
    }
    const randomProtein = Math.floor(Math.random() * 15) + 10; 
    const randomKcal = Math.floor(Math.random() * 200) + 150;
    return `${randomProtein}g Protein, ${randomKcal} Kcal`;
  };

  const handlePrint = () => {
    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'absolute';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = '0';
    document.body.appendChild(printFrame);

    const mealPlanTableHtml = document.getElementById('mealPlanTableContainer')?.outerHTML || '';
    
    
    const nutritionChartElement = document.getElementById('nutritionChartPrint');
    let nutritionChartHtml = '';
    if (nutritionChartElement) {
      const canvas = nutritionChartElement.querySelector('canvas');
      if (canvas) {
        const canvasImageBase64 = canvas.toDataURL('image/png');
        nutritionChartHtml = `<img src="${canvasImageBase64}" alt="Nutrition Chart" style="max-width: 400px; margin: 20px auto; display: block;" />`;
      } else {
         nutritionChartHtml = nutritionChartElement.innerHTML;
      }
    }
    
    const healthInsightsHtml = document.getElementById('personalizedHealthInsightsPrint')?.outerHTML || '';

    const cuisinePref = preferences.cuisines && preferences.cuisines.length > 0 ? cuisinesList.find(c=>c.id === preferences.cuisines[0])?.name : 'Any Cuisine';
    const dietPref = preferences.dietaryPreferences && preferences.dietaryPreferences.length > 0 ? dietaryPreferencesList.find(d=>d.id === preferences.dietaryPreferences[0])?.name : 'Any Diet';
    const title = `NutriGuide - Your Weekly Meal Plan (${cuisinePref}, ${dietPref})`;
    
    const printDocument = printFrame.contentWindow.document;
    printDocument.open();
    printDocument.write(`
      <html>
        <head>
          <title>${title}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
            body { 
              font-family: 'Inter', sans-serif !important; 
              margin: 1cm; 
              color: #2d3748;
              -webkit-print-color-adjust: exact !important; 
              print-color-adjust: exact !important;
            }
            h1 { text-align: center; font-size: 20px; margin-bottom: 15px; color: black !important; }
            h2 { font-size: 16px; margin-top: 20px; margin-bottom: 10px; border-bottom: 1px solid #ccc; padding-bottom: 5px; color: black !important;}

            #mealPlanTableContainer { page-break-before: auto !important; }
            #mealPlanTableContainer table { width: 100%; border-collapse: collapse; margin-top: 5px; font-size: 8pt !important; table-layout: auto !important; }
            #mealPlanTableContainer th, #mealPlanTableContainer td { border: 1px solid #555 !important; padding: 3px !important; text-align: left; vertical-align: top; word-wrap: break-word; overflow-wrap: break-word; font-size: 7pt !important; }
            #mealPlanTableContainer th { background-color: #dbdbdb !important; color: black !important; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; }
            #mealPlanTableContainer .meal-type-print { font-weight: bold !important; color: black !important; font-size: 7.5pt !important; }
            #mealPlanTableContainer .meal-name-print { font-weight: 500; font-size: 7pt !important; }
            #mealPlanTableContainer .nutrition-details-print { font-size: 6pt !important; color: #333 !important; margin-top: 2px; }
            
            .print-section { margin-top: 15mm !important; page-break-before: always !important; background-color: white !important; }
            .print-section:first-of-type { page-break-before: auto !important; } /* If the table itself is considered a section */
            
            /* Styles for the copied Personalized Health Insights */
            #personalizedHealthInsightsPrint { margin-top: 15mm !important; page-break-before: always !important; }
            #personalizedHealthInsightsPrint .text-2xl { font-size: 14pt !important; font-weight: bold; color: black !important; margin-bottom: 10px; } /* Card Title */
            #personalizedHealthInsightsPrint .text-secondary-text { font-size: 9pt !important; color: #444 !important; } /* Card Description */
            #personalizedHealthInsightsPrint .text-xl { font-size: 12pt !important; font-weight: bold; color: black !important; border-bottom: 1px solid #aaa !important; padding-bottom: 4px !important; margin-bottom: 8px !important;} /* Condition Name */
            #personalizedHealthInsightsPrint .text-md { font-size: 10pt !important; font-weight: bold; color: black !important; margin-bottom: 4px !important;} /* Subheadings like "Foods to avoid" */
            #personalizedHealthInsightsPrint ul { list-style-type: disc; padding-left: 20px !important; margin-bottom: 10px !important; }
            #personalizedHealthInsightsPrint li { font-size: 8pt !important; color: #222 !important; margin-bottom: 3px !important; }


            .sticky { position: static !important; } 
            .no-print { display: none !important; }
            @page { size: A4 landscape; margin: 1cm; }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          
          ${mealPlanTableHtml}

          ${nutritionChartHtml ? `<div class="print-section"><h2>Nutritional Overview</h2>${nutritionChartHtml}</div>` : ''}
          ${healthInsightsHtml ? `<div class="print-section"><h2>Personalized Health Insights</h2>${healthInsightsHtml.replace(/style="color: hsl\(var\(--primary\)\);"/g, 'style="color: black !important;"')}</div>` : ''}


        </body>
      </html>
    `);
    printDocument.close();

    printFrame.contentWindow.focus();
    printFrame.contentWindow.print();
    
    setTimeout(() => {
      document.body.removeChild(printFrame);
    }, 1000);
  };
  
  const cardVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.6, -0.05, 0.01, 0.99] }}
  };

  return (
    <motion.div variants={cardVariants} initial="hidden" animate="visible">
      <Card className="shadow-2xl mt-10 overflow-hidden border-border/70 bg-card rounded-xl backdrop-blur-sm bg-white/80">
        <CardHeader className="bg-gradient-to-r from-primary/10 via-card to-accent/10 p-6 flex flex-row justify-between items-center rounded-t-xl border-b border-border">
          <div>
            <CardTitle className="text-3xl font-bold text-primary-text flex items-center">
              <CalendarDays className="mr-3.5 h-8 w-8 text-primary" />
              Your Weekly Meal Plan
            </CardTitle>
            <CardDescription className="text-secondary-text mt-1.5">
              Here's a healthy and delicious plan tailored for you!
            </CardDescription>
          </div>
          <Button onClick={handlePrint} variant="default" size="lg" className="bg-primary text-primary-foreground hover:bg-primary/85 no-print shadow-lg hover:shadow-primary/40 transition-all duration-300 group">
            <Printer className="mr-2 h-5 w-5" /> Print Plan <ChevronRight size={20} className="ml-1 group-hover:translate-x-1 transition-transform duration-300"/>
          </Button>
        </CardHeader>
        <CardContent className="p-0" id="mealPlanTableContainer">
          <div className="overflow-x-auto">
            <Table className="min-w-full">
              <TableHeader>
                <TableRow className="bg-slate-50 hover:bg-slate-100/80 transition-colors border-b border-border">
                  <TableHead className="w-[220px] px-5 py-4 text-left text-sm font-bold uppercase tracking-wider text-primary-text sticky left-0 bg-slate-50 z-10 border-r border-border">Meal Time</TableHead>
                  {daysOfWeek.map(day => (
                    <TableHead key={day} className="px-5 py-4 text-center text-sm font-bold uppercase tracking-wider text-primary-text min-w-[230px]">{day}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(mealTypes).map(([mealKey, mealInfo]) => (
                  <TableRow key={mealKey} className="border-b border-border/70 hover:bg-sky-50/50 transition-colors duration-150">
                    <TableCell className="px-5 py-4 font-semibold text-primary sticky left-0 bg-card z-10 border-r border-border meal-type-print">
                      {mealInfo.name}
                    </TableCell>
                    {daysOfWeek.map(day => {
                      const mealName = mealPlan[day]?.[mealKey] || 'Not specified';
                      const nutritionDetails = mealName !== 'Not specified' && !mealName.startsWith('No suitable') ? getIllustrativeNutrition(mealName) : '';
                      return (
                        <TableCell key={`${day}-${mealKey}`} className="px-5 py-4 text-sm text-secondary-text text-center">
                          <div className="meal-name-print font-medium text-slate-700">{mealName}</div>
                          {nutritionDetails && (
                            <div className="text-xs mt-1.5 nutrition-details-print" style={{color: 'hsl(var(--nutrient-detail-text))'}}>
                              {nutritionDetails}
                            </div>
                          )}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MealPlanDisplay;