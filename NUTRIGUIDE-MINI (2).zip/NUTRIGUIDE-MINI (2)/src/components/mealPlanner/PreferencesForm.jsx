import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox'; 
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'; 
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { healthConditionsList, cuisinesList, dietaryPreferencesList, allergiesList } from '@/data/mealData';
import { Zap, Utensils, Settings2, ChevronRight } from 'lucide-react';

const PreferencesForm = ({ onSubmit, initialPreferences, isLoading }) => {
  const [selectedConditions, setSelectedConditions] = useState(initialPreferences.healthConditions || []);
  const [selectedCuisine, setSelectedCuisine] = useState(initialPreferences.cuisines?.[0] || ''); 
  const [selectedDietaryPreference, setSelectedDietaryPreference] = useState(initialPreferences.dietaryPreferences?.[0] || ''); 
  const [selectedAllergies, setSelectedAllergies] = useState(initialPreferences.allergies || []);

  const handleMultiSelectChange = (currentSelected, setter) => (itemId, isNoneOption = false) => {
    if (isNoneOption) {
      // If "None" is checked, clear all other selections.
      // If "None" is unchecked (meaning it was checked and user clicked it again), do nothing or allow re-selection of items.
      // For simplicity, clicking "None" when already selected keeps it selected and others cleared.
      setter([]); 
    } else {
      // If any other item is checked, ensure "None" is effectively cleared.
      // If an item is checked, add it. If unchecked, remove it.
      const newSelected = currentSelected.includes(itemId)
        ? currentSelected.filter(id => id !== itemId)
        : [...currentSelected.filter(id => id !== 'none'), itemId]; // Ensure 'none' is not in the list if a specific item is chosen
      setter(newSelected);
    }
  };
  

  const handleConditionChange = (itemId, isNoneClicked) => {
    if (isNoneClicked) {
      setSelectedConditions(selectedConditions.length === 0 && !itemId ? [] : (selectedConditions.includes('none-conditions') ? [] : ['none-conditions']));
    } else {
      setSelectedConditions(prev => {
        const alreadySelected = prev.includes(itemId);
        if (alreadySelected) {
          return prev.filter(id => id !== itemId);
        } else {
          return [...prev.filter(id => id !== 'none-conditions'), itemId];
        }
      });
    }
  };
  
  const handleAllergyChange = (itemId, isNoneClicked) => {
     if (isNoneClicked) {
      setSelectedAllergies(selectedAllergies.length === 0 && !itemId ? [] : (selectedAllergies.includes('none-allergies') ? [] : ['none-allergies']));
    } else {
      setSelectedAllergies(prev => {
        const alreadySelected = prev.includes(itemId);
        if (alreadySelected) {
          return prev.filter(id => id !== itemId);
        } else {
          return [...prev.filter(id => id !== 'none-allergies'), itemId];
        }
      });
    }
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      healthConditions: selectedConditions.filter(id => id !== 'none-conditions'), // Filter out 'none' marker
      cuisines: selectedCuisine ? [selectedCuisine] : [], 
      dietaryPreferences: selectedDietaryPreference ? [selectedDietaryPreference] : [], 
      allergies: selectedAllergies.filter(id => id !== 'none-allergies'), // Filter out 'none' marker
    });
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 25 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.6, -0.05, 0.01, 0.99] } }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, x: -15 },
    visible: (i) => ({ 
      opacity: 1, 
      x: 0, 
      transition: { 
        delay: i * 0.05,
        type: 'spring',
        stiffness: 300,
        damping: 20 
      } 
    })
  };

  const CheckboxGroup = ({ title, items, selectedItems, onChange, noneOptionLabel = "None", noneOptionId }) => (
    <motion.div variants={sectionVariants} initial="hidden" animate="visible" className="flex flex-col space-y-3.5 p-5 bg-white/70 rounded-xl border border-border/80 shadow-lg hover:shadow-primary/20 transition-all duration-300 h-full">
      <Label className="text-xl font-bold text-primary-text border-b-2 border-primary/30 pb-2.5 mb-1.5 flex items-center">
        {title}
      </Label>
      <div className="space-y-3 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
        {items.map((item, idx) => (
          <motion.div custom={idx} variants={itemVariants} initial="hidden" animate="visible" key={item.id} className="flex items-center space-x-2.5 p-2.5 rounded-lg hover:bg-primary/10 transition-colors duration-200">
            <Checkbox
              id={`${noneOptionId}-${item.id}`}
              checked={selectedItems.includes(item.id)}
              onCheckedChange={() => onChange(item.id, false)}
              disabled={isLoading || (selectedItems.includes(noneOptionId) && item.id !== noneOptionId)}
              className="border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground transform scale-110"
            />
            <Label htmlFor={`${noneOptionId}-${item.id}`} className="text-sm font-medium text-secondary-text cursor-pointer flex-1">
              {item.name}
            </Label>
          </motion.div>
        ))}
        <motion.div custom={items.length} variants={itemVariants} initial="hidden" animate="visible" className="flex items-center space-x-2.5 p-2.5 rounded-lg hover:bg-primary/10 transition-colors duration-200 mt-2.5 border-t border-border/50 pt-3.5">
           <Checkbox
              id={noneOptionId}
              checked={selectedItems.includes(noneOptionId) || selectedItems.length === 0}
              onCheckedChange={() => onChange(noneOptionId, true)}
              disabled={isLoading}
              className="border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground transform scale-110"
            />
            <Label htmlFor={noneOptionId} className="text-sm font-medium text-secondary-text cursor-pointer flex-1">
              {noneOptionLabel}
            </Label>
        </motion.div>
      </div>
    </motion.div>
  );

  const SingleSelectRadioGroup = ({ title, items, selectedItem, onChange, noneOptionLabel = "Any" }) => (
    <motion.div variants={sectionVariants} initial="hidden" animate="visible" className="flex flex-col space-y-3.5 p-5 bg-white/70 rounded-xl border border-border/80 shadow-lg hover:shadow-primary/20 transition-all duration-300 h-full">
      <Label className="text-xl font-bold text-primary-text border-b-2 border-primary/30 pb-2.5 mb-1.5 flex items-center">
       {title}
      </Label>
      <RadioGroup value={selectedItem} onValueChange={onChange} className="space-y-3 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
        {items.map((item, idx) => (
          <motion.div custom={idx} variants={itemVariants} initial="hidden" animate="visible" key={item.id} className="flex items-center space-x-2.5 p-2.5 rounded-lg hover:bg-primary/10 transition-colors duration-200">
            <RadioGroupItem value={item.id} id={`${title.toLowerCase().replace(/\s+/g, '-')}-${item.id}`} disabled={isLoading} className="border-primary text-primary data-[state=checked]:border-primary" />
            <Label htmlFor={`${title.toLowerCase().replace(/\s+/g, '-')}-${item.id}`} className="text-sm font-medium text-secondary-text cursor-pointer flex-1">
              {item.name}
            </Label>
          </motion.div>
        ))}
        <motion.div custom={items.length} variants={itemVariants} initial="hidden" animate="visible" className="flex items-center space-x-2.5 p-2.5 rounded-lg hover:bg-primary/10 transition-colors duration-200 mt-2.5 border-t border-border/50 pt-3.5">
          <RadioGroupItem value={""} id={`${title.toLowerCase().replace(/\s+/g, '-')}-none`} disabled={isLoading} className="border-primary text-primary" />
          <Label htmlFor={`${title.toLowerCase().replace(/\s+/g, '-')}-none`} className="text-sm font-medium text-secondary-text cursor-pointer flex-1">
            {noneOptionLabel}
          </Label>
        </motion.div>
      </RadioGroup>
    </motion.div>
  );

  return (
    <Card className="shadow-2xl overflow-hidden border-border/70 bg-card rounded-xl backdrop-blur-sm bg-white/60">
      <CardHeader className="bg-gradient-to-r from-primary/10 via-card to-accent/10 p-7 rounded-t-xl border-b border-border">
        <CardTitle className="text-3xl font-bold text-primary-text flex items-center tracking-tight">
          <Settings2 className="mr-3.5 h-9 w-9 text-primary stroke-[2.5]" />
          Customize Your Meal Plan
        </CardTitle>
        <CardDescription className="text-secondary-text text-md mt-1">
          Select your preferences below, and our AI will craft a unique and healthy plan for you.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-7 space-y-10 bg-card">
        <form onSubmit={handleSubmit} className="space-y-12">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">
            <CheckboxGroup 
              title="Health Conditions" 
              items={healthConditionsList} 
              selectedItems={selectedConditions} 
              onChange={handleConditionChange}
              noneOptionId="none-conditions"
            />
            <CheckboxGroup 
              title="Allergies" 
              items={allergiesList} 
              selectedItems={selectedAllergies} 
              onChange={handleAllergyChange}
              noneOptionId="none-allergies"
            />
            <SingleSelectRadioGroup
              title="Preferred Cuisine"
              items={cuisinesList}
              selectedItem={selectedCuisine}
              onChange={setSelectedCuisine}
              noneOptionLabel="Any Cuisine"
            />
            <SingleSelectRadioGroup
              title="Dietary Preference"
              items={dietaryPreferencesList}
              selectedItem={selectedDietaryPreference}
              onChange={setSelectedDietaryPreference}
              noneOptionLabel="No Specific Preference"
            />
          </div>
          
          <CardFooter className="pt-12 flex justify-center bg-card -mx-7 -mb-7 px-7 py-8 rounded-b-xl border-t border-border/70">
            <Button 
              type="submit" 
              size="xl" 
              className="bg-gradient-to-r from-primary to-blue-500 text-primary-foreground hover:from-primary/90 hover:to-blue-500/90 font-bold text-xl py-4 px-20 shadow-xl hover:shadow-primary/50 transform hover:scale-[1.03] transition-all duration-300 focus:ring-4 focus:ring-primary/50 focus:ring-offset-2 group"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Zap className="mr-2.5 h-6 w-6 animate-pulse" /> Generating Your Plan...
                </>
              ) : (
                <>
                  <Utensils className="mr-2.5 h-6 w-6" /> Generate My Meal Plan <ChevronRight size={24} className="ml-2 group-hover:translate-x-1.5 transition-transform duration-300"/>
                </>
              )}
            </Button>
          </CardFooter>
        </form>
      </CardContent>
    </Card>
  );
};

export default PreferencesForm;