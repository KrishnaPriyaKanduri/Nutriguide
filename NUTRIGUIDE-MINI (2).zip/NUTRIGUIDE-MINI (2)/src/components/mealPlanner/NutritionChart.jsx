import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PieChart as LucidePieChart } from 'lucide-react';

const NutritionChart = ({ data }) => {
  const chartRef = useRef(null);

  const chartColorsForDrawing = [
    'hsl(350, 85%, 60%)', // Vibrant Red for Protein
    'hsl(130, 65%, 55%)', // Lush Green for Fats
    'hsl(260, 70%, 65%)', // Deep Purple for Carbs
    'hsl(25, 90%, 60%)',  // Bright Orange for Fiber
    'hsl(190, 75%, 50%)', // Cool Teal for Vitamins
    'hsl(220, 30%, 80%)', // Light Slate Blue for any other data
  ];
  
  useEffect(() => {
    if (chartRef.current && data) {
      const canvas = chartRef.current;
      const ctx = canvas.getContext('2d');
      const { width, height } = canvas;
      ctx.clearRect(0, 0, width, height);

      const total = Object.values(data).reduce((sum, value) => sum + value, 0);
      if (total === 0) {
        ctx.textAlign = 'center';
        ctx.fillStyle = 'hsl(var(--muted-foreground))';
        ctx.font = '16px "Inter", sans-serif';
        ctx.fillText("No data to display", width / 2, height / 2);
        return;
      }

      let currentAngle = -0.5 * Math.PI; // Start at the top
      const centerX = width / 2;
      const centerY = height / 1.85; 
      const radius = Math.min(width, height) / 3.2; // Adjusted radius for full pie

      const legendItems = [];
      let colorIndex = 0;

      const orderedDataKeys = ['protein', 'fats', 'carbs', 'fiber', 'vitamins'];
      const dataEntries = orderedDataKeys.filter(key => data[key] > 0).map(key => [key, data[key]]);
      
      Object.keys(data).forEach(key => {
        if (!orderedDataKeys.includes(key) && data[key] > 0) {
          dataEntries.push([key, data[key]]);
        }
      });

      dataEntries.forEach(([key, value]) => {
        const sliceAngle = (value / total) * 2 * Math.PI;
        const color = chartColorsForDrawing[colorIndex % chartColorsForDrawing.length];
        colorIndex++;

        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.shadowColor = 'rgba(0,0,0,0.1)';
        ctx.shadowBlur = 3;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        ctx.fill();
        ctx.shadowColor = 'transparent';

        legendItems.push({ label: key.charAt(0).toUpperCase() + key.slice(1), value, color, percentage: ((value / total) * 100).toFixed(1) });
        currentAngle += sliceAngle;
      });
      
      // Legend
      const legendXStart = 30;
      const legendYStart = 30;
      const legendItemHeight = 26;
      const legendBoxSize = 12;
      ctx.font = '13px "Inter", sans-serif';
      ctx.textAlign = 'left';

      legendItems.forEach((item, index) => {
        const yPos = legendYStart + index * legendItemHeight;
        ctx.fillStyle = item.color;
        ctx.fillRect(legendXStart, yPos, legendBoxSize, legendBoxSize);
        ctx.fillStyle = 'hsl(var(--secondary-text))';
        ctx.fillText(`${item.label}: ${item.percentage}%`, legendXStart + legendBoxSize + 10, yPos + legendBoxSize - 2);
      });
    }
  }, [data]); 

  const getCanvasBase64 = () => {
    if (chartRef.current) {
      return chartRef.current.toDataURL('image/png');
    }
    return null;
  };

  return (
    <motion.div
      id="nutritionChartPrint"
      data-canvas-base64={getCanvasBase64()} // Store base64 for printing
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut", delay: 0.3 }}
    >
      <Card className="shadow-2xl mt-10 overflow-hidden border-border/70 bg-card rounded-xl backdrop-blur-sm bg-white/80">
        <CardHeader className="bg-gradient-to-r from-primary/10 via-card to-accent/10 p-6 rounded-t-xl border-b border-border">
          <CardTitle className="text-2xl font-bold text-primary-text flex items-center">
            <LucidePieChart className="mr-3 h-7 w-7 text-primary" />
            Nutritional Overview (Illustrative)
          </CardTitle>
          <CardDescription className="text-secondary-text">
            A general breakdown of macronutrients in your suggested plan.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex flex-col items-center justify-center min-h-[350px]">
          <canvas ref={chartRef} width="400" height="320"></canvas>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default NutritionChart;