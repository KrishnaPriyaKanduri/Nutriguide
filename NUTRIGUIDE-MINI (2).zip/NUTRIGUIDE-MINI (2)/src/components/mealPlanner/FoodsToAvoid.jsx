import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { healthInsightData, healthConditionsList } from '@/data/mealData'; 
import { ListChecks } from 'lucide-react';

const PersonalizedHealthInsights = ({ healthConditions }) => {
  if (!healthConditions || healthConditions.length === 0) {
    return null;
  }

  const insights = {};
  const subheadingColor = 'hsl(var(--primary))'; // Consistent color for all subheadings

  healthConditions.forEach(conditionId => {
    const conditionData = healthInsightData[conditionId];
    if (conditionData) {
      if (!insights[conditionId]) {
        insights[conditionId] = {
          conditionName: healthConditionsList.find(hc => hc.id === conditionId)?.name || conditionId,
          foodsToAvoid: new Set(),
          exercises: [],
          yoga: [],
          tips: [],
        };
      }
      if (conditionData.foodsToAvoid) {
        conditionData.foodsToAvoid.slice(0, 3).forEach(food => insights[conditionId].foodsToAvoid.add(food));
      }
      if (conditionData.exercises) {
        insights[conditionId].exercises = conditionData.exercises.slice(0, conditionId === 'obesity' ? 3 : 2);
      }
      if (conditionData.yoga) {
        insights[conditionId].yoga = conditionData.yoga.slice(0, 2);
      }
      if (conditionId === 'obesity' && conditionData.tips) {
        insights[conditionId].tips = conditionData.tips.slice(0, 3);
      }
    }
  });

  const listItemVariants = {
    hidden: { opacity: 0, x: -15 },
    visible: (i) => ({
      opacity: 1,
      x: 0,
      transition: {
        delay: i * 0.08,
        type: 'spring',
        stiffness: 260,
        damping: 20
      }
    })
  };

  const insightKeys = Object.keys(insights).filter(key => 
    insights[key].foodsToAvoid.size > 0 || 
    insights[key].exercises.length > 0 || 
    insights[key].yoga.length > 0 ||
    insights[key].tips.length > 0
  );

  if (insightKeys.length === 0) {
    return (
       <motion.div
        id="personalizedHealthInsightsPrint"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut", delay: 0.4 }}
        className="mt-10"
      >
        <Card className="shadow-lg border-border bg-card rounded-xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-accent/5 p-6">
            <CardTitle className="text-2xl font-bold text-primary-text flex items-center">
              <ListChecks className="mr-3 h-7 w-7 text-primary" />
              Personalized Health Insights
            </CardTitle>
            <CardDescription className="text-secondary-text">
              General tips for well-being.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
             <p className="text-secondary-text text-center">No specific health insights for your current selections. Focus on a balanced and varied diet and regular physical activity!</p>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      id="personalizedHealthInsightsPrint"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut", delay: 0.4 }}
      className="mt-10"
    >
      <Card className="shadow-xl border-border bg-card rounded-xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/10 via-card to-accent/10 p-6 border-b border-border">
          <CardTitle className="text-2xl font-bold text-primary-text flex items-center">
            <ListChecks className="mr-3 h-7 w-7 text-primary" />
            Personalized Health Insights
          </CardTitle>
          <CardDescription className="text-secondary-text">
            Tips and recommendations based on your selected health conditions.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-10">
          {insightKeys.map(key => {
            const insight = insights[key];
            const foodsToAvoidArray = Array.from(insight.foodsToAvoid);
            
            return (
              <div key={key} className="space-y-6 p-5 bg-background rounded-lg border border-border/70 shadow-inner hover:shadow-md transition-shadow duration-300">
                <h3 className="text-xl font-semibold text-primary mb-4 border-b-2 border-primary/40 pb-3">
                  For {insight.conditionName}:
                </h3>
                
                {foodsToAvoidArray.length > 0 && (
                  <div>
                    <h4 className="text-md font-semibold mb-2.5" style={{color: subheadingColor}}>
                      Foods to be Mindful Of:
                    </h4>
                    <ul className="space-y-2 pl-5 list-disc" style={{ markerColor: subheadingColor }}>
                      {foodsToAvoidArray.map((food, index) => (
                        <motion.li 
                          key={`avoid-${key}-${index}`}
                          custom={index}
                          variants={listItemVariants}
                          initial="hidden"
                          animate="visible"
                          className="text-sm text-secondary-text leading-relaxed"
                        >
                          {food}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                )}

                {insight.exercises && insight.exercises.length > 0 && (
                  <div>
                    <h4 className="text-md font-semibold mb-2.5" style={{color: subheadingColor}}>
                      Suggested Exercises:
                    </h4>
                    <ul className="space-y-2 pl-5 list-disc" style={{ markerColor: subheadingColor }}>
                      {insight.exercises.map((exercise, index) => (
                        <motion.li 
                          key={`ex-${key}-${index}`}
                          custom={index + foodsToAvoidArray.length}
                          variants={listItemVariants}
                          initial="hidden"
                          animate="visible"
                          className="text-sm text-secondary-text leading-relaxed"
                        >
                          {exercise}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                )}

                {insight.yoga && insight.yoga.length > 0 && (
                   <div>
                    <h4 className="text-md font-semibold mb-2.5" style={{color: subheadingColor}}>
                      Helpful Yoga Poses:
                    </h4>
                    <ul className="space-y-2 pl-5 list-disc" style={{ markerColor: subheadingColor }}>
                      {insight.yoga.map((pose, index) => (
                        <motion.li 
                          key={`yoga-${key}-${index}`}
                          custom={index + foodsToAvoidArray.length + (insight.exercises?.length || 0)}
                          variants={listItemVariants}
                          initial="hidden"
                          animate="visible"
                          className="text-sm text-secondary-text leading-relaxed"
                        >
                          {pose}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {insight.tips && insight.tips.length > 0 && (
                   <div>
                    <h4 className="text-md font-semibold mb-2.5" style={{color: subheadingColor}}>
                      Additional Tips:
                    </h4>
                    <ul className="space-y-2 pl-5 list-disc" style={{ markerColor: subheadingColor }}>
                      {insight.tips.map((tip, index) => (
                        <motion.li 
                          key={`tip-${key}-${index}`}
                          custom={index + foodsToAvoidArray.length + (insight.exercises?.length || 0) + (insight.yoga?.length || 0)}
                          variants={listItemVariants}
                          initial="hidden"
                          animate="visible"
                          className="text-sm text-secondary-text leading-relaxed"
                        >
                          {tip}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PersonalizedHealthInsights;