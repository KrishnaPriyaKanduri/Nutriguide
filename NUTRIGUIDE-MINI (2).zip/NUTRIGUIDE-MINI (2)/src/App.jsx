import React from 'react';
import MealPlanner from '@/pages/MealPlanner';
import { Toaster } from '@/components/ui/toaster';
import { motion } from 'framer-motion';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-sky-100 text-foreground p-4 sm:p-6 md:p-8 flex flex-col items-center">
      <motion.header
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.6, -0.05, 0.01, 0.99] }}
        className="w-full max-w-7xl mb-12 text-center pt-6"
      >
        <h1 className="text-5xl sm:text-6xl font-black tracking-tight drop-shadow-sm" style={{ color: 'hsl(var(--primary-text))' }}>
          NutriGuide
        </h1>
        <p className="text-xl text-primary-text/80 mt-2 font-medium">
          Your Personalized Nutrition Planner
        </p>
        <p className="text-lg text-secondary-text mt-4 max-w-2xl mx-auto">
          Craft healthy and delicious meal plans tailored just for you!
        </p>
      </motion.header>
      <main className="w-full max-w-7xl">
        <MealPlanner />
      </main>
      <Toaster />
      <footer className="mt-20 py-10 border-t border-border/60 w-full text-center text-muted-foreground text-sm">
        <p>&copy; {new Date().getFullYear()} NutriGuide. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;