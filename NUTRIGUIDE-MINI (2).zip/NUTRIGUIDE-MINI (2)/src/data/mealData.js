export const healthConditionsList = [
  { id: 'obesity', name: 'Obesity', impactScore: -2 },
  { id: 'hypertension', name: 'Hypertension', impactScore: -2 },
  { id: 'thyroid', name: 'Thyroid', impactScore: -1 },
  { id: 'diabetes', name: 'Diabetes', impactScore: -3 },
];

export const allergiesList = [
  { id: 'nuts', name: 'Nuts', associatedTags: ['nuts', 'almond', 'walnut', 'cashew', 'peanut'] },
  { id: 'eggs', name: 'Eggs', associatedTags: ['eggs', 'egg', 'omelette', 'frittata', 'bhurji'] },
  { id: 'soy', name: 'Soy', associatedTags: ['soy', 'tofu', 'edamame', 'miso', 'tempeh'] },
  { id: 'gluten', name: 'Gluten', associatedTags: ['gluten', 'wheat', 'barley', 'rye', 'bread', 'pasta_unless_gf', 'roti_unless_gf', 'poha_sometimes_wheat'] },
];

export const cuisinesList = [
  { id: 'indian', name: 'Indian', preferenceScore: 2 },
  { id: 'italian', name: 'Italian', preferenceScore: 2 },
  { id: 'mexican', name: 'Mexican', preferenceScore: 2 },
  { id: 'chinese', name: 'Chinese', preferenceScore: 2 },
];

export const dietaryPreferencesList = [
  { id: 'vegetarian', name: 'Vegetarian', preferenceScore: 1, allowedTags: ['vegetarian', 'vegan'], disallowedTags: ['non_vegetarian', 'fish', 'chicken', 'meat', 'shellfish'] },
  { id: 'non_vegetarian', name: 'Non-Vegetarian', preferenceScore: 0, allowedTags: ['non_vegetarian', 'eggetarian', 'vegetarian', 'vegan', 'fish', 'chicken', 'meat', 'shellfish'], disallowedTags: [] },
  { id: 'eggetarian', name: 'Eggetarian', preferenceScore: 1, allowedTags: ['eggetarian', 'vegetarian', 'vegan', 'eggs'], disallowedTags: ['non_vegetarian', 'fish', 'chicken', 'meat', 'shellfish'] },
  { id: 'vegan', name: 'Vegan', preferenceScore: 2, allowedTags: ['vegan'], disallowedTags: ['non_vegetarian', 'eggetarian', 'vegetarian_not_strict_vegan', 'dairy', 'milk', 'cheese', 'yogurt', 'honey', 'eggs', 'fish', 'chicken', 'meat', 'shellfish'] },
];

export const mealTypes = {
  earlyMorning: { name: 'Early Morning (6-7 AM)', baseScore: 1 },
  breakfast: { name: 'Breakfast (8-9 AM)', baseScore: 3 },
  midMorningSnack: { name: 'Mid-Morning Snack (11 AM)', baseScore: 1},
  lunch: { name: 'Lunch (1-2 PM)', baseScore: 3 },
  eveningSnack: { name: 'Evening Snack (4-5 PM)', baseScore: 1 },
  dinner: { name: 'Dinner (7-8 PM)', baseScore: 2 },
};

export const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const illustrativeNutritionDetails = () => {
  const protein = Math.floor(Math.random() * 10) + 5; 
  const kcal = Math.floor(Math.random() * 150) + 100;
  return `${protein}g Protein, ${kcal} Kcal`;
};
const illustrativeMainMealNutritionDetails = () => {
  const protein = Math.floor(Math.random() * 15) + 15; 
  const kcal = Math.floor(Math.random() * 250) + 250;
  return `${protein}g Protein, ${kcal} Kcal`;
};

export const foodItems = [
  { id: 1, name: 'Warm Lemon Water', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 2, name: 'Green Tea', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 3, name: 'Herbal Infusion (Chamomile)', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 4, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 4, name: 'Soaked Chia Seeds in Water', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 5, name: 'Diluted Apple Cider Vinegar', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['thyroid'], nutritionalScore: 3, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 6, name: 'Plain Coconut Water', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 7, name: 'Amla Juice (Indian Gooseberry)', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 61, name: 'Turmeric Water with Black Pepper', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 62, name: 'Ginger Tea', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 4, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 63, name: 'Warm Water with Honey', type: 'earlyMorning', tags: ['vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['diabetes', 'vegan'], nutritionalScore: 3, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 84, name: 'Fennel Seed Water', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 4, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 85, name: 'Coriander Seed Water', type: 'earlyMorning', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 4, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },

  // Breakfast (Removed Mediterranean specific items, kept general or other cuisines)
  { id: 10, name: 'Vegetable Poha (Flattened Rice)', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free_optional_peanuts', 'soy_free', 'gluten_free', 'poha'], avoidFor: ['diabetes'], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 11, name: 'Moong Dal Cheela (Lentil Pancakes)', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 14, name: 'Steamed Idli with Sambhar', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 15, name: 'Quinoa Upma with Vegetables', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 17, name: 'Tofu Scramble with Turmeric (Soy)', type: 'breakfast', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'gluten_free', 'soy', 'tofu'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 18, name: 'Corn Tortilla with Black Beans & Salsa', type: 'breakfast', cuisine: 'mexican', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 19, name: 'Buckwheat Pancakes (GF)', type: 'breakfast', cuisine: 'italian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 20, name: 'Besan Cheela (Chickpea Flour Pancake)', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 21, name: 'Ragi Porridge (Finger Millet)', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 65, name: 'Mexican Breakfast Bowl (Quinoa, Beans, Salsa)', type: 'breakfast', cuisine: 'mexican', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 66, name: 'Congee (Rice Porridge) with Vegetables', type: 'breakfast', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 67, name: 'Italian Baked Eggs with Tomato & Herbs', type: 'breakfast', cuisine: 'italian', tags: ['eggetarian', 'vegetarian', 'dairy_free_optional_cheese', 'nut_free', 'soy_free', 'gluten_free', 'eggs'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 86, name: 'Amaranth Porridge with Fruits', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 87, name: 'Vegetable Uttapam (GF)', type: 'breakfast', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 8, name: 'Oatmeal with Berries & Seeds (GF Oats)', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free_optional_seeds', 'soy_free', 'gluten_free_oats'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 9, name: 'Spinach & Mushroom Omelette (DF)', type: 'breakfast', cuisine: 'any', tags: ['eggetarian', 'non_vegetarian', 'dairy_free_optional_cheese', 'nut_free', 'soy_free', 'gluten_free', 'eggs'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 12, name: 'Avocado Toast on GF Bread', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'bread'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 13, name: 'Greek Yogurt with Seeds (Dairy)', type: 'breakfast', cuisine: 'any', tags: ['vegetarian', 'nut_free', 'soy_free', 'gluten_free', 'dairy', 'yogurt'], avoidFor: ['diabetes', 'vegan'], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Changed almonds to seeds
  { id: 16, name: 'Mixed Fruit Salad with Mint & Lime', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 22, name: 'Spinach Banana Smoothie (Seed Milk)', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'soy_free', 'gluten_free', 'nut_free_sub_seed_milk'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Changed almond milk to seed milk
  { id: 64, name: 'Chia Seed Pudding with Berries', type: 'breakfast', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },


  { id: 23, name: 'Apple Slices with Sunflower Seed Butter', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 24, name: 'Handful of Seeds (Pumpkin/Sunflower)', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'soy_free', 'gluten_free', 'nut_free'], avoidFor: [], nutritionalScore: 8, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Changed walnuts to seeds
  { id: 25, name: 'Mixed Sprouts Salad', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 26, name: 'A Ripe Pear', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 27, name: 'Small Bowl of Mixed Berries', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 28, name: 'Cucumber & Carrot Sticks', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 29, name: 'Air-Popped Popcorn (Plain)', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['hypertension'], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 68, name: 'Orange Slices', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 69, name: 'Roasted Makhana (Fox Nuts)', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 70, name: 'A Banana', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['diabetes'], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 88, name: 'Peach Slices', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 89, name: 'Small handful of Pumpkin Seeds', type: 'midMorningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  
  // Lunch (Removed Mediterranean specific items, kept general or other cuisines)
  { id: 31, name: 'Red Lentil Soup with Brown Rice', type: 'lunch', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 32, name: 'Chana Masala with GF Roti', type: 'lunch', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'roti_unless_gf'], avoidFor: ['diabetes'], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 35, name: 'Chicken Fajita Bowl (No Tortilla)', type: 'lunch', cuisine: 'mexican', tags: ['non_vegetarian', 'chicken', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 36, name: 'Minestrone Soup (GF Pasta)', type: 'lunch', cuisine: 'italian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'pasta_unless_gf'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 37, name: 'Stir-fried Bok Choy & Mushrooms (Tamari)', type: 'lunch', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_optional', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 38, name: 'Vegetable Biryani with Cucumber Salad', type: 'lunch', cuisine: 'indian', tags: ['vegetarian', 'vegan', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 39, name: 'Black Bean Burgers (Lettuce Wrap)', type: 'lunch', cuisine: 'mexican', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 41, name: 'Asparagus & Pea Risotto (DF)', type: 'lunch', cuisine: 'italian', tags: ['vegetarian', 'vegan', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 71, name: 'Dal Tadka with Steamed Rice', type: 'lunch', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 73, name: 'Lentil Tacos with Corn Tortillas', type: 'lunch', cuisine: 'mexican', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 74, name: 'Sichuan Style Green Beans with Rice', type: 'lunch', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 75, name: 'Caprese Salad with GF Croutons (DF Cheese)', type: 'lunch', cuisine: 'italian', tags: ['vegetarian', 'vegan', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Made DF
  { id: 30, name: 'Grilled Chicken Breast, Quinoa & Veggies', type: 'lunch', cuisine: 'any', tags: ['non_vegetarian', 'chicken', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 33, name: 'Baked Fish with Roasted Sweet Potatoes', type: 'lunch', cuisine: 'any', tags: ['non_vegetarian', 'fish', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Changed salmon to general fish
  { id: 34, name: 'Large Green Salad with Chickpeas & Avocado', type: 'lunch', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free_tahini_ok', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 40, name: 'Egg Salad on GF Crackers (DF Mayo)', type: 'lunch', cuisine: 'any', tags: ['eggetarian', 'non_vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'eggs'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Specified DF mayo
  { id: 90, name: 'Quinoa Salad with Roasted Vegetables', type: 'lunch', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 91, name: 'Tuna Salad (Canned Tuna in Water) with Lettuce Cups (DF Mayo)', type: 'lunch', cuisine: 'any', tags: ['non_vegetarian', 'fish', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Specified DF mayo

  { id: 42, name: 'Herbal Tea & Rice Cakes with Tomato', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 43, name: 'Spiced Coconut Buttermilk (DF)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'nut_free', 'soy_free', 'gluten_free', 'dairy_free'], avoidFor: ['diabetes'], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Made DF
  { id: 44, name: 'Bell Pepper Strips with Guacamole', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 45, name: 'Hard Boiled Egg', type: 'eveningSnack', tags: ['eggetarian', 'non_vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'eggs'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 46, name: 'Small bowl of Coconut Kefir (DF)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'nut_free', 'soy_free', 'gluten_free', 'dairy_free'], avoidFor: [], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Made DF
  { id: 47, name: 'Dry Roasted Edamame (Soy)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'gluten_free', 'soy', 'edamame'], avoidFor: ['hypertension'], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 48, name: 'Cucumber Raita (DF Yogurt)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'nut_free', 'soy_free', 'gluten_free', 'dairy_free', 'yogurt'], avoidFor: [], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Specified DF yogurt
  { id: 76, name: 'A handful of Seeds (Sunflower/Pumpkin)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'soy_free', 'gluten_free', 'nut_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Changed almonds to seeds
  { id: 77, name: 'Steamed Sweet Potato Cubes', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['diabetes'], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 78, name: 'Olives and Cherry Tomatoes', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['hypertension_if_salted_olives'], nutritionalScore: 5, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() },
  { id: 92, name: 'A handful of Roasted Chickpeas (unsalted)', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'dairy_free', 'soy_free', 'gluten_free', 'nut_free'], avoidFor: [], nutritionalScore: 7, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Changed pistachios
  { id: 93, name: 'Coconut Yogurt (Plain, DF) with a sprinkle of Cinnamon', type: 'eveningSnack', tags: ['vegan', 'vegetarian', 'nut_free', 'soy_free', 'gluten_free', 'dairy_free', 'yogurt'], avoidFor: ['diabetes'], nutritionalScore: 6, cuisine: 'any', illustrativeNutrition: illustrativeNutritionDetails() }, // Made DF

  // Dinner (Removed Mediterranean specific items, kept general or other cuisines)
  { id: 50, name: 'Palak Dal (Spinach Lentils) with Millet Roti', type: 'dinner', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'roti_unless_gf'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 51, name: 'Shrimp Scampi with Zucchini Noodles (GF, DF)', type: 'dinner', cuisine: 'italian', tags: ['non_vegetarian', 'shellfish', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Specified DF
  { id: 52, name: 'Vegetable Tofu Curry (Soy) with Cauli Rice', type: 'dinner', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'gluten_free', 'soy', 'tofu'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 55, name: 'Egg Bhurji (Indian Scrambled Eggs, DF)', type: 'dinner', cuisine: 'indian', tags: ['eggetarian', 'non_vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free', 'eggs', 'bhurji'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Specified DF
  { id: 56, name: 'Chicken Vegetable Soup (Low Sodium)', type: 'dinner', cuisine: 'mexican', tags: ['non_vegetarian', 'chicken', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: ['hypertension'], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 57, name: 'Mushroom Risotto (DF)', type: 'dinner', cuisine: 'italian', tags: ['vegetarian', 'vegan', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 58, name: 'Moong Dal Khichdi with Steamed Carrots', type: 'dinner', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 59, name: 'Mapo Tofu (Sichuan Tofu - Soy, Spicy)', type: 'dinner', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'gluten_free_tamari', 'soy', 'tofu'], avoidFor: ['obesity_spicy'], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 60, name: 'Steamed Fish with Ginger & Scallions', type: 'dinner', cuisine: 'chinese', tags: ['non_vegetarian', 'fish', 'dairy_free', 'nut_free', 'soy_free_optional_soy_sauce', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 79, name: 'Vegetable Korma with Coconut Milk', type: 'dinner', cuisine: 'indian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 81, name: 'Chicken Enchilada Casserole (GF Corn Tortillas, DF)', type: 'dinner', cuisine: 'mexican', tags: ['non_vegetarian', 'chicken', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() }, // Specified DF
  { id: 82, name: 'Kung Pao Cauliflower (No Peanuts)', type: 'dinner', cuisine: 'chinese', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_optional', 'gluten_free_tamari'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 83, name: 'Polenta with Roasted Vegetables', type: 'dinner', cuisine: 'italian', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 6, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 49, name: 'Baked Chicken, Rosemary & Green Beans', type: 'dinner', cuisine: 'any', tags: ['non_vegetarian', 'chicken', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 53, name: 'Lentil Shepherd’s Pie (Sweet Potato Top)', type: 'dinner', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 9, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 54, name: 'Grilled Tofu Steaks with Sautéed Kale (Soy)', type: 'dinner', cuisine: 'any', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'gluten_free', 'soy', 'tofu'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 80, name: 'Baked Cod with Lemon and Herbs', type: 'dinner', cuisine: 'any', tags: ['non_vegetarian', 'fish', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 94, name: 'Turkey Meatballs with Zucchini Noodles', type: 'dinner', cuisine: 'italian', tags: ['non_vegetarian', 'meat', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 8, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
  { id: 95, name: 'Black Bean Soup with a dollop of DF Sour Cream', type: 'dinner', cuisine: 'mexican', tags: ['vegan', 'vegetarian', 'dairy_free', 'nut_free', 'soy_free', 'gluten_free'], avoidFor: [], nutritionalScore: 7, illustrativeNutrition: illustrativeMainMealNutritionDetails() },
];

export const healthInsightData = {
  obesity: {
    foodsToAvoid: ["Deep fried foods", "Sugary drinks & desserts", "Processed meats (sausages, bacon)"],
    exercises: ["Brisk Walking (30-45 mins daily)", "Cycling (30 mins, 3-4 times/week)", "Strength Training (2-3 times/week, full body)"],
    yoga: ["Sun Salutation (Surya Namaskar) - 5-10 rounds", "Warrior Pose Series (Virabhadrasana I, II, III)"],
    tips: ["Focus on whole, unprocessed foods and increase fiber intake.", "Practice mindful eating: eat slowly and pay attention to hunger/fullness cues.", "Ensure adequate sleep, as it impacts hormones regulating appetite."]
  },
  hypertension: {
    foodsToAvoid: ["High-sodium processed foods (canned soups, chips, deli meats)", "Pickles and preserved olives/foods", "Excessive table salt and salty condiments"],
    exercises: ["Aerobic exercises like Jogging or Swimming (30 mins, 5 times/week)", "Tai Chi or Qigong for stress reduction"],
    yoga: ["Corpse Pose (Savasana) - 5-10 mins daily for relaxation", "Bridge Pose (Setu Bandhasana) - gentle backbend"]
  },
  thyroid: {
    foodsToAvoid: ["Raw cruciferous vegetables in large amounts (e.g., broccoli, cabbage - cooked is generally fine)", "Excessive soy products (tofu, soy milk if hypothyroid)", "Gluten (if diagnosed with Hashimoto's or celiac disease)"],
    exercises: ["Low-impact aerobics (Walking, Elliptical - 30 mins, 3-5 times/week)", "Gentle Strength Training with light weights"],
    yoga: ["Shoulder Stand (Sarvangasana - consult doctor if neck issues)", "Fish Pose (Matsyasana) - counterpose to shoulder stand"]
  },
  diabetes: {
    foodsToAvoid: ["Refined sugars (candies, pastries, sugary cereals, sodas)", "White bread, white pasta, white rice - choose whole grains", "Sweetened beverages and most fruit juices (whole fruit is better)"],
    exercises: ["Regular Walking (at least 30 mins daily, ideally after meals)", "Resistance Band Exercises or light weight training (2-3 times/week)"],
    yoga: ["Legs-Up-the-Wall Pose (Viparita Karani) - aids circulation", "Seated Forward Bend (Paschimottanasana) - calming"]
  }
};
